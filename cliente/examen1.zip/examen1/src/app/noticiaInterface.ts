export interface Noticia{
  titulo: string;
  descripcion :string;
  imagen :string;
  fecha_publicacion :string;
}
